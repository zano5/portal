export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyCB1A29b5ZQlAilyTB5Z3jx7ScUPG5x7c0",
    authDomain: "portal-a772d.firebaseapp.com",
    databaseURL: "https://portal-a772d.firebaseio.com",
    projectId: "portal-a772d",
    storageBucket: "portal-a772d.appspot.com",
    messagingSenderId: "41928390418",
    appId: "1:41928390418:web:98121e50a6c799e534a5cb",
    measurementId: "G-ZXC21T80W7"
  }
};